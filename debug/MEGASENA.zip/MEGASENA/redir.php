<?php
function redir($url="/") {
	$parametros = explode('?', $url);
	?>

	<form method="post" id="redirPost" action="<?php echo $parametros[0]?>">
	<?php
		if ($parametros[1]) {
			$paramurl = $parametros[1];
			$parametros = explode('&', $paramurl);
			foreach ($parametros as $paramurl) {
				$variavel = explode('=', $paramurl);
				echo '<input type="hidden" name="'.$variavel[0].'" value="'.urldecode($variavel[1]).'">';
			}
		}
		?>
	<input type="submit" style="display: none"/>
	</form>
	<script type="text/javascript">
    	document.getElementById("redirPost").submit();
  	</script>
  	<?php
	}
?>