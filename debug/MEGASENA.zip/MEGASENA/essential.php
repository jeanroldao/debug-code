<?php
	include_once("adodb5/adodb.inc.php");
	$DB = NewADOConnection('postgres');
	$DB->Connect("127.0.0.1", "postgres", 'postgres', "mega");

	$ADODB_FETCH_MODE = ADODB_FETCH_ASSOC;

	include_once("redir.php");
?>
