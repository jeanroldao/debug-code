<?php
  require_once('essential.php');

  $handle = fopen('numeros.txt', 'r');
  $jogos = array();

  if ($handle) {
    while (($buffer = fgets($handle)) !== false) {
      $buffer = trim($buffer);
      $seq = explode(' ', $buffer);
      $seq = array_filter($seq);
      $seq = array_merge(array(), $seq);

      sort($seq);
      $jogos[] = $seq;
    }
  }

  for ($i=0; $i<count($jogos); $i++) {
    for ($k=0; $k<count($jogos); $k++) {
      if ($jogos[$i] == $jogos[$k] && $i<>$k) {
        echo 'Pobrema!';
        echo '<pre>';
        print_r($jogos[$i]);
        echo '</pre>';
      }
    }
  }

  $saida = fopen('saida.txt', 'w');
  if ($saida) {

    foreach ($jogos as $jogo) {
      $str = $jogo[0] . ' - ' . $jogo[1] . ' - ' . $jogo[2] . ' - ' . $jogo[3] . ' - ' . $jogo[4] . ' - ' . $jogo[5] . PHP_EOL;
      fputs($saida, $str);

      $sql = 'SELECT MAX(id_aposta) as max FROM apostas';
      $res = $DB->Execute($sql);
      if ($res === false) {
        echo 'Erro';
        exit;
      } else {
        $idAposta = $res->fields['max'] + 1;

        $sql = 'INSERT INTO apostas(id_aposta, vl_primeiro, vl_segundo, vl_terceiro, vl_quarto, vl_quinto, vl_sexto, nm_jogo)
                VALUES ('.$idAposta.', '.$jogo[0].', '.$jogo[1].', '.$jogo[2].', '.$jogo[3].', '.$jogo[4].', '.$jogo[5].', \'DITECH\');';
        $res = $DB->Execute($sql);
        if ($res === false) {
          echo 'Erro 02';
          exit;
        }
      }
    }
  }
?>