CREATE TABLE apostas
(
   id_aposta integer, 
   vl_primeiro integer, 
   vl_segundo integer, 
   vl_terceiro integer, 
   vl_quarto integer, 
   vl_quinto integer, 
   vl_sexto integer, 
   nm_jogo varchar(100), 
   CONSTRAINT index_aposta PRIMARY KEY (id_aposta)
) 