<?php
require_once('essential.php');

// Confere apostas
if ($_POST['conferir']) {

  $aposta = array();
  $aposta[] = $_POST['primeiro'];
  $aposta[] = $_POST['segundo'];
  $aposta[] = $_POST['terceiro'];
  $aposta[] = $_POST['quarto'];
  $aposta[] = $_POST['quinto'];
  $aposta[] = $_POST['sexto'];

  $aposta = array_unique($aposta);

  $sql = 'SELECT * FROM apostas';
  $res = $DB->Execute($sql);
  if ($res == false) {
    echo 'ERRO';
    exit;
  }

  while (!$res->EOF) {

    $possivel = array();
    $possivel[] = $res->fields['vl_primeiro'];
    $possivel[] = $res->fields['vl_segundo'];
    $possivel[] = $res->fields['vl_terceiro'];
    $possivel[] = $res->fields['vl_quarto'];
    $possivel[] = $res->fields['vl_quinto'];
    $possivel[] = $res->fields['vl_sexto'];

    $sorte = array_intersect($aposta, $possivel);

    if (count($sorte) == 6) {
      echo 'MEGA SENA!!!  ' . $res->fields['nm_jogo'];
      echo ' ----> Jogo: ' . $possivel[0] . ' - ' . $possivel[1] . ' - ' . $possivel[2] . ' - ' . $possivel[3] . ' - ' . $possivel[4] . ' - ' . $possivel[5];
      echo '<br>';
    } elseif (count($sorte) == 5) {
      echo 'QUINA!!  '. $res->fields['nm_jogo'];
      echo ' ----> Jogo: ' . $possivel[0] . ' - ' . $possivel[1] . ' - ' . $possivel[2] . ' - ' . $possivel[3] . ' - ' . $possivel[4] . ' - ' . $possivel[5];
      echo '<br>';
    } elseif (count($sorte) == 4) {
      echo 'QUADRA!  '. $res->fields['nm_jogo'];
      echo ' ----> Jogo: ' . $possivel[0] . ' - ' . $possivel[1] . ' - ' . $possivel[2] . ' - ' . $possivel[3] . ' - ' . $possivel[4] . ' - ' . $possivel[5];
      echo '<br>';
    }

    $res->MoveNext();
  }
}

// Adiciona uma aposta
if ($_POST['acao'] == 'add') {
  redir('adicionar.php');
}

// Edita a aposta seleciona
if ($_POST['acao'] == 'edt') {
  if (count($_POST['aposta']) > 1) {
    echo 'Selecione apenas uma aposta para edição.';
  } elseif ($_POST['aposta'] == 0) {
    echo 'Selecione ao menos uma aposta para edição.';
  } else {
    redir('editar.php?idAposta='.$_POST['aposta'][0]);
  }
}

// Exclui uma aposta
if ($_POST['acao'] == 'exc') {
  if (count($_POST['aposta']) < 1) {
    echo 'Selecione uma ou mais apostas para exclusão.';
  } else {
    redir('excluir.php?apostas='.implode(',', $_POST['aposta']));
  }
}

$filtro = array();
$filtro[] = $_POST['primeiro'];
$filtro[] = $_POST['segundo'];
$filtro[] = $_POST['terceiro'];
$filtro[] = $_POST['quarto'];
$filtro[] = $_POST['quinto'];
$filtro[] = $_POST['sexto'];

$filtro = array_filter($filtro);

$sql = 'SELECT *
        FROM apostas';
$res = $DB->Execute($sql);
if ($res === false) {
  echo 'Erro';
}

$contador = 0;
while (!$res->EOF) {
  $listaApostas[$contador]['id_aposta'] = $res->fields['id_aposta'];
  $listaApostas[$contador]['nm_jogo']   = $res->fields['nm_jogo'];
  $listaApostas[$contador]['vl_primeiro'] = $res->fields['vl_primeiro'];
  $listaApostas[$contador]['vl_segundo'] = $res->fields['vl_segundo'];
  $listaApostas[$contador]['vl_terceiro'] = $res->fields['vl_terceiro'];
  $listaApostas[$contador]['vl_quarto'] = $res->fields['vl_quarto'];
  $listaApostas[$contador]['vl_quinto'] = $res->fields['vl_quinto'];
  $listaApostas[$contador]['vl_sexto'] = $res->fields['vl_sexto'];

  $contador++;
  $res->MoveNext();
}
?>

<html>
<head>
<title>Conferência MEGA-SENA</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<script type="text/javascript">
function evento(str) {
  var oAcao = document.getElementById('acao');
  oAcao.value = str;
	formapostas.submit();
}

function limpar() {
  document.getElementById('primeiro').value = '';
  document.getElementById('segundo').value = '';
  document.getElementById('terceiro').value = '';
  document.getElementById('quarto').value = '';
  document.getElementById('quinto').value = '';
  document.getElementById('sexto').value = '';
}
</script>

</head>
<body>
  <form action="<?=$_SERVER['PHP_SELF']?>" method="POST" name="conferencia">
    <p>Conferência Mega-Sena:</p>
    <table>
      <tr>
        <td align="center">1º</td>
        <td align="center">2º</td>
        <td align="center">3º</td>
        <td align="center">4º</td>
        <td align="center">5º</td>
        <td align="center">6º</td>
      </tr>
      <tr>
        <td><input type="text" id="primeiro" name="primeiro" value="<?=$_POST['primeiro']?>"></td>
        <td><input type="text" id="segundo" name="segundo" value="<?=$_POST['segundo']?>"></td>
        <td><input type="text" id="terceiro" name="terceiro" value="<?=$_POST['terceiro']?>""></td>
        <td><input type="text" id="quarto" name="quarto" value="<?=$_POST['quarto']?>"></td>
        <td><input type="text" id="quinto" name="quinto" value="<?=$_POST['quinto']?>"></td>
        <td><input type="text" id="sexto" name="sexto" value="<?=$_POST['sexto']?>"></td>
      </tr>
      <tr>
        <td colspan="3" align="center"><input type="submit" id="conferir" name="conferir" value="Conferir sorte do campeão"></td>
        <td colspan="3" align="center"><input type="button" id="limpa" name="limpa" value="Limpar" onclick="limpar()"></td>
      </tr>
    </table>
  </form>

  <form action="<?=$_SERVER['PHP_SELF']?>" method="POST" name="formapostas">
    <input type="hidden" name="acao" id="acao" value="">
    <p>Apostas</p>
    <table>
      <tr>
        <td><input type="button" id="add" name="add" value="Adicionar" onClick="evento('add')"></td>
        <td><input type="button" id="edt" name="edt" value="Editar" onClick="evento('edt')"></td>
        <td><input type="button" id="exc" name="exc" value="Excluir" onClick="evento('exc')"></td>
      </tr>
    </table>

    <table border="0">
      <tr>
        <td width="1%">&nbsp;</td>
        <td width="10%">Nome</td>
        <td width="10%">Primeiro</td>
        <td width="10%">Segundo</td>
        <td width="10%">Terceiro</td>
        <td width="10%">Quarto</td>
        <td width="10%">Quinto</td>
        <td width="10%">Sexto</td>
      </tr>
      <?php   $estilo = 'impar';
        for($i=0; $i<count($listaApostas); $i++) {
          if (!empty($filtro)) {
            $aux = array_intersect($filtro, $listaApostas[$i]);
            if (count($aux) != count($filtro)) {
              continue;
            }
          }
          $estilo = ($estilo == 'par')? 'impar' : 'par';  ?>
          <tr class="<?=$estilo?>">
            <td><input type="checkbox" name="aposta[]" value="<?=$listaApostas[$i]['id_aposta']?>"></td>
            <td><?=$listaApostas[$i]['nm_jogo']?></td>
            <td><?=$listaApostas[$i]['vl_primeiro']?></td>
            <td><?=$listaApostas[$i]['vl_segundo']?></td>
            <td><?=$listaApostas[$i]['vl_terceiro']?></td>
            <td><?=$listaApostas[$i]['vl_quarto']?></td>
            <td><?=$listaApostas[$i]['vl_quinto']?></td>
            <td><?=$listaApostas[$i]['vl_sexto']?></td>
          </tr>
      <?php
        }
      ?>
    </table>
  </form>

</body>
</html>