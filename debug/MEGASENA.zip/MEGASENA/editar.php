<?php
  require_once('essential.php');

// Edita uma aposta
if ($_POST['salvar']) {
  if (!$_POST['idAposta'] || !$_POST['primeiro'] || !$_POST['segundo'] || !$_POST['terceiro'] || !$_POST['quarto'] || !$_POST['quinto'] || !$_POST['sexto']) {
    echo 'Preencha todos campos.';
  } else {
    $sql = 'UPDATE apostas SET vl_primeiro='.$_POST['primeiro'].', vl_segundo='.$_POST['segundo'].', vl_terceiro='.$_POST['terceiro'].', vl_quarto='.$_POST['quarto'].', vl_quinto='.$_POST['quinto'].', vl_sexto='.$_POST['sexto'].', nm_jogo=\''.$_POST['nome'].'\'
              WHERE id_aposta = '.$_POST['idAposta'];
    $res = $DB->Execute($sql);
    if ($res === false) {
      echo 'Erro';
    } else {
      redir('index.php');
    }
  }
}


if ($_POST['idAposta']) {
  $sql = 'SELECT * FROM apostas WHERE id_aposta = ' . $_POST['idAposta'];
  $res = $DB->Execute($sql);
  if ($res == false) {
    echo 'Behhh erro';
  } else {
    $aposta = $res->fields;
  }
}

?>

<html>
<head>
<title>Editando</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>
  <form action="<?=$_SERVER['PHP_SELF']?>" method="POST" name="aposta">
    <input type="hidden" name="idAposta" id="idAposta" value="<?=$_POST['idAposta']?>">
    <p>Editar aposta:</p>
    <p>Nome: <input type="text" name="nome" id="nome" value="<?=$aposta['nm_jogo']?>"></p>
    <table>
      <tr>
        <td align="center">1</td>
        <td align="center">2</td>
        <td align="center">3</td>
        <td align="center">4</td>
        <td align="center">5</td>
        <td align="center">6</td>
      </tr>
      <tr>
        <td><input type="text" id="primeiro" name="primeiro" value="<?=$aposta['vl_primeiro']?>"></td>
        <td><input type="text" id="segundo" name="segundo" value="<?=$aposta['vl_segundo']?>"></td>
        <td><input type="text" id="terceiro" name="terceiro" value="<?=$aposta['vl_terceiro']?>"></td>
        <td><input type="text" id="quarto" name="quarto" value="<?=$aposta['vl_quarto']?>"></td>
        <td><input type="text" id="quinto" name="quinto" value="<?=$aposta['vl_quinto']?>"></td>
        <td><input type="text" id="sexto" name="sexto" value="<?=$aposta['vl_sexto']?>"></td>
      </tr>
      <tr>
        <td colspan="6" align="center"><input type="submit" id="salvar" name="salvar" value="SALVAR"></td>
      </tr>
    </table>
  </form>
</body>
</html>