<?php
  require_once('essential.php');

if ($_POST['apostas']) {
  $sql = 'SELECT * FROM apostas WHERE id_aposta IN (' . $_POST['apostas'] . ')';
  $res = $DB->Execute($sql);
  if ($res == false) {
    echo 'Behhh erro';
  } else {

    $contador = 0;
    while (!$res->EOF) {
      $aposta[$contador] = $res->fields;

      $contador++;
      $res->MoveNext();
    }
  }
}

// Exclui uma aposta
if ($_POST['excluir']) {
  $sql = 'DELETE FROM apostas
            WHERE id_aposta IN ( '.$_POST['apostas'] . ' )';
  $res = $DB->Execute($sql);
  if ($res === false) {
    echo 'Erro';
  } else {
    redir('index.php');
  }
}
?>
<html>
<head>
<title>Excluir</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>
  <form action="<?=$_SERVER['PHP_SELF']?>" method="POST" name="aposta">
  <input type="hidden" name="apostas" id="apostas" value="<?=$_POST['apostas']?>">
    <p>Deseja excluir a(s) aposta(s):</p>
    <table>
      <?php
      for ($i=0; $i<count($aposta); $i++) {
      ?>
        <p>Nome: <?=$aposta[$i]['nm_jogo']?></p>
        <table>
          <tr>
            <td><?=$aposta[$i]['vl_primeiro']?></td>
            <td><?=$aposta[$i]['vl_segundo']?></td>
            <td><?=$aposta[$i]['vl_terceiro']?></td>
            <td><?=$aposta[$i]['vl_quarto']?></td>
            <td><?=$aposta[$i]['vl_quinto']?></td>
            <td><?=$aposta[$i]['vl_sexto']?></td>
          </tr>
        </table>
      <?php
      }
      ?>
      <tr>
        <td colspan="6" align="center"><input type="submit" id="excluir" name="excluir" value="EXCLUIR"></td>
      </tr>
    </table>
  </form>
</body>
</html>