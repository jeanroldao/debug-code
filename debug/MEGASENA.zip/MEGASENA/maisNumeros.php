<?php
require_once('essential.php');

$handle = fopen('jogos.txt', 'r');
if ($handle) {
  while (($buffer = fgets($handle)) !== false) {
    $numeros = array();
    $numeros = explode(' ', $buffer);

    $sql = 'SELECT MAX(id_aposta) as max FROM apostas';
    $res = $DB->Execute($sql);
    if ($res === false) {
      echo 'Erro';
      exit;
    } else {
      $idAposta = $res->fields['max'] + 1;

      $sql = 'INSERT INTO apostas(id_aposta, vl_primeiro, vl_segundo, vl_terceiro, vl_quarto, vl_quinto, vl_sexto, nm_jogo)
              VALUES ('.$idAposta.', '.$numeros[0].', '.$numeros[1].', '.$numeros[2].', '.$numeros[3].', '.$numeros[4].', '.$numeros[5].', \'RANDOMICOS DA LOJA\');';
      $res = $DB->Execute($sql);
      if ($res === false) {
        echo 'Erro';
        exit;
      }
    }
  }
  if (!feof($handle)) {
    echo "Error: unexpected fgets() fail\n";
  }
  fclose($handle);
  echo 'SUCESSO AO IMPORTAR NOVOS NÚMEROS!';
}
?>