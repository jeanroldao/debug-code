<?php
  require_once('essential.php');

// Adiciona uma aposta
if ($_POST['salvar']) {
  if (!$_POST['primeiro'] || !$_POST['segundo'] || !$_POST['terceiro'] || !$_POST['quarto'] || !$_POST['quinto'] || !$_POST['sexto']) {
    echo 'Preencha todos campos.';
  } else {
    $sql = 'SELECT MAX(id_aposta) as max FROM apostas';
    $res = $DB->Execute($sql);
    if ($res === false) {
      echo 'Erro';
    } else {
      $idAposta = $res->fields['max'] + 1;

      $sql = 'INSERT INTO apostas(id_aposta, vl_primeiro, vl_segundo, vl_terceiro, vl_quarto, vl_quinto, vl_sexto, nm_jogo)
              VALUES ('.$idAposta.', '.$_POST['primeiro'].', '.$_POST['segundo'].', '.$_POST['terceiro'].', '.$_POST['quarto'].', '.$_POST['quinto'].', '.$_POST['sexto'].', \''.$_POST['nome'].'\');';

      $res = $DB->Execute($sql);
      if ($res === false) {
        echo 'Erro';
      } else {
        redir('index.php');
      }
    }
  }
}

?>

<html>
<head>
<title>Adicionando</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>
  <form action="<?=$_SERVER['PHP_SELF']?>" method="POST" name="aposta">
    <p>Adicionar aposta:</p>
    <p>Nome: <input type="text" name="nome" id="nome"></p>
    <table>
      <tr>
        <td align="center">1</td>
        <td align="center">2</td>
        <td align="center">3</td>
        <td align="center">4</td>
        <td align="center">5</td>
        <td align="center">6</td>
      </tr>
      <tr>
        <td><input type="text" id="primeiro" name="primeiro"></td>
        <td><input type="text" id="segundo" name="segundo"></td>
        <td><input type="text" id="terceiro" name="terceiro"></td>
        <td><input type="text" id="quarto" name="quarto"></td>
        <td><input type="text" id="quinto" name="quinto"></td>
        <td><input type="text" id="sexto" name="sexto"></td>
      </tr>
      <tr>
        <td colspan="6" align="center"><input type="submit" id="salvar" name="salvar" value="SALVAR"></td>
      </tr>
    </table>
  </form>
</body>
</html>